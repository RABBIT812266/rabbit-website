RABBIT — UPI CHECKOUT + GOOGLE SHEET + TELEGRAM + EMAIL

FLOW: Pay button > UPI app chooser > customer returns > form opens automatically
      (name, email, phone, Roman Hindi/English, UTR) > Google Sheet row + Telegram + email to you.

STEP 1 - index.html mein sabse neeche CFG edit karo:
   UPI_ID   = "rabbittt@nyes (already set)"        PAYEE = "Rabbit"        AMOUNT = "99.00"
   SCRIPT_URL = (Step 2 ka /exec link)      HELP_URL = (aapka Google Form link)

STEP 2 - Google Sheet + Telegram + Email (apps-script/Code.gs):
   1. Nayi Google Sheet banao > Extensions > Apps Script > Code.gs ka poora code paste karo.
   2. Upar CFG mein bharo: TELEGRAM_BOT_TOKEN (@BotFather se), TELEGRAM_CHAT_ID, OWNER_EMAIL.
      Chat ID: apne bot ko "hi" bhejo, phir browser mein
      https://api.telegram.org/bot<TOKEN>/getUpdates kholo > "chat":{"id":...}
   3. Deploy > New deployment > Web app > Execute as: Me, Who has access: Anyone > Deploy > /exec link copy karo.
   4. Wo link CFG.SCRIPT_URL mein daalo. (Code badalne par har baar "New version" deploy karna.)

STEP 3 - Netlify: is poore folder ko drag & drop karo (index.html root mein hai).

NOTE: Personal UPI mein payment apne aap confirm nahi hoti. Sheet mein status "Pending verification" aata hai;
UTR ko apne UPI app/bank mein match karke verify karo. Duplicate UTR par sheet aur Telegram mein alert aata hai.
