/**
 * Rabbit orders -> Google Sheet + your Email + Telegram (+ optional thank-you email to customer)
 * Deploy: Extensions > Apps Script (from your Google Sheet) > paste > Deploy > New deployment > Web app
 *         Execute as: Me | Who has access: Anyone  -> copy the /exec URL into index.html (CFG.SCRIPT_URL)
 */
const CFG = {
  TELEGRAM_BOT_TOKEN: 'PASTE_BOT_TOKEN',   // from @BotFather
  TELEGRAM_CHAT_ID:   'PASTE_CHAT_ID',     // your chat id
  OWNER_EMAIL:        'you@gmail.com',     // details will be mailed here
  SHEET_NAME:         'Orders',
  EMAIL_CUSTOMER:     true                 // send "Thank you for ordering" to customer
};
const HEAD = ['Time','Order Ref','Name','Email','Phone','Edition','UTR / UPI Ref','Amount','Status'];

function doPost(e) {
  const lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const d = JSON.parse(e.postData.contents || '{}');
    if (d.website) return out('ok');                                   // honeypot
    const name = clean(d.name), email = clean(d.email), phone = clean(d.phone), ed = clean(d.edition), utr = clean(d.utr), ref = clean(d.ref);
    if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !/^[6-9]\d{9}$/.test(phone) || !/^\d{12}$/.test(utr) || !/^(Roman Hindi|English)$/.test(ed)) return out('invalid');
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sh = ss.getSheetByName(CFG.SHEET_NAME) || ss.insertSheet(CFG.SHEET_NAME);
    if (sh.getLastRow() === 0) { sh.appendRow(HEAD); sh.setFrozenRows(1); sh.getRange(1,1,1,HEAD.length).setFontWeight('bold').setBackground('#e10613').setFontColor('#fff'); }
    const dup = sh.getLastRow() > 1 && sh.getRange(2,7,sh.getLastRow()-1,1).getValues().flat().map(String).indexOf(utr) > -1;
    const status = dup ? 'DUPLICATE UTR - CHECK' : 'Pending verification';
    sh.appendRow([new Date(), ref, name, email, "'" + phone, ed, "'" + utr, 99, status]);
    const msg = `NEW RABBIT ORDER${dup ? ' (DUPLICATE UTR!)' : ''}\nRef: ${ref}\nName: ${name}\nEmail: ${email}\nPhone: ${phone}\nEdition: ${ed}\nUTR: ${utr}\nAmount: Rs 99\nStatus: ${status}\n(Verify UTR in your bank/UPI app)`;
    try { UrlFetchApp.fetch('https://api.telegram.org/bot' + CFG.TELEGRAM_BOT_TOKEN + '/sendMessage', { method: 'post', payload: { chat_id: CFG.TELEGRAM_CHAT_ID, text: msg }, muteHttpExceptions: true }); } catch (x) {}
    try { MailApp.sendEmail(CFG.OWNER_EMAIL, 'New Rabbit order - ' + name + ' (' + ed + ')', msg + '\n\nSheet: ' + ss.getUrl()); } catch (x) {}
    if (CFG.EMAIL_CUSTOMER) try {
      MailApp.sendEmail({ to: email, name: 'Rabbit', subject: 'Thank you for ordering - How to Scam with People\'s Mind',
        body: `Hi ${name},\n\nThank you for ordering! We received your details (${ed} edition, Ref ${ref}).\nYour payment will be verified. After the pre-order sale ends on 30 October 2026, the ebook may be delivered to this email at any time. 30 October 2026 is not a guaranteed delivery date.\n\n- Rabbit` });
    } catch (x) {}
    return out('ok');
  } catch (err) { return out('error'); } finally { lock.releaseLock(); }
}
function doGet() { return out('Rabbit endpoint is live'); }
function clean(v) { return String(v == null ? '' : v).replace(/[\r\n]+/g, ' ').trim().slice(0, 120); }
function out(t) { return ContentService.createTextOutput(t); }
